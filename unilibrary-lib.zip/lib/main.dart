import 'package:flutter/material.dart';

import 'signin.dart';

void main() {
  runApp(const UniLibraryApp());
}

class UniLibraryApp extends StatelessWidget {
  const UniLibraryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UniLibrary - <Your Roll No>',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.teal,
        colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.teal),
        useMaterial3: false,
      ),
      home: const SignInScreen(),
    );
  }
}
